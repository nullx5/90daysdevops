(function($) {

	"use strct";


})(jQuery);
